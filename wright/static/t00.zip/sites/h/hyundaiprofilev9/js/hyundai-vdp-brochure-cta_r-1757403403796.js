var _____WB$wombat$assign$function_____=function(name){return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name))||self[name];};if(!self.__WB_pmw){self.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}{
let window = _____WB$wombat$assign$function_____("window");
let self = _____WB$wombat$assign$function_____("self");
let document = _____WB$wombat$assign$function_____("document");
let location = _____WB$wombat$assign$function_____("location");
let top = _____WB$wombat$assign$function_____("top");
let parent = _____WB$wombat$assign$function_____("parent");
let frames = _____WB$wombat$assign$function_____("frames");
let opens = _____WB$wombat$assign$function_____("opens");
hyundaiBrochureCTA = function(){
	/*
		Hyundai does not have an API and provided us with a manual list of links to product brochures. They requested
		a CTA button be placed on new rVDP pages that link to these product brochures where applicable. The following
		function will place a CTA in the sidebar of rVDP if a matching YEAR and MODEL are found.

		If this becomes a long-term support issue, a more robust solution will need to be created. Best-case scenario
		would be for hyundai to provide us with an actual API to fetch these brochures.
	*/

	var modelYear = DDC.dataLayer.vehicles[0].modelYear,
		model = DDC.dataLayer.vehicles[0].model,
		trim = DDC.dataLayer.vehicles[0].trim,
		brochureLink = "";

	switch(modelYear + " " + model) {
		case "2019 Kona":
			brochureLink = "http://viewer.zmags.com/publication/28f37962";
			break;
		case "2020 Kona":
			brochureLink = "http://viewer.zmags.com/publication/ec30deab";
			break;
		case "2019 Tucson":
			brochureLink = "http://viewer.zmags.com/publication/2f65b9a9";
			break;
		case "2019 Santa Fe":
			brochureLink = "http://viewer.zmags.com/publication/ed6a8bf8";
			break;
		case "2020 Santa Fe":
			brochureLink = "http://viewer.zmags.com/publication/9d86d42f";
			break;
		case "2019 Santa Fe XL":
			brochureLink = "http://viewer.zmags.com/publication/cd04a52a";
			break;
		case "2020 Palisade":
			brochureLink = "http://viewer.zmags.com/publication/d49ef13d";
			break;
		case "2019 Elantra":
			brochureLink = "http://viewer.zmags.com/publication/28f33866";
			break;
		case "2019 Sonata":
			brochureLink = "http://viewer.zmags.com/publication/cc00e1bc";
			break;
		case "2019 Accent":
			brochureLink = "http://viewer.zmags.com/publication/ec6bcaf8";
			break;
		case "2019 Elantra GT":
			brochureLink = "http://viewer.zmags.com/publication/4d865127";
			break;
		case "2019 Veloster":
			if (trim == "N") {
				brochureLink = "http://viewer.zmags.com/publication/6f24d92d";
			} else {
				brochureLink = "http://viewer.zmags.com/publication/ad73ec6a";
			}
			break;
		case "2020 Veloster":
			brochureLink = "http://viewer.zmags.com/publication/8cdff3b9";
			break;
		case "2019 Veloster N":

			break;
		case "2020 Veloster N":

			break;
		case "2019 Ioniq":
			brochureLink = "http://viewer.zmags.com/publication/c111a52b";
			break;
		case "2019 Nexo":
			brochureLink = "http://viewer.zmags.com/publication/1cc67326";
	}

	if (brochureLink) {

		/* Desktop */
		$(".vdp-responsive .vdp-sidebar-main").append('<a class="btn btn-default btn-sm btn-block" href="' + brochureLink + '" target="_blank">View Brochure</a>');

		/* Mobile */
		$(".vdp-responsive .mobile .contact-info .tels").first().append('<a class="btn btn-default btn-sm btn-block" href="' + brochureLink + '" target="_blank">View Brochure</a>');

	}
}();

}